require('babel-register');
require('./app/main.js');
